	function Hreff() {
			document.location.href="http://localhost/Projet/Views/admin.php";
	}
