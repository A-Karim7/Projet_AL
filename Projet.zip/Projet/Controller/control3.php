<?php
require_once('../Modele/connect.php');
        require('../Modele/affich.php');
?>
