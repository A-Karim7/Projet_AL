<?php
require_once('../Modele/connect.php');
require('../Modele/afiche.php');
?>
