<?php
session_destroy();

header('Location: ../Views/accueil.php');
?>
