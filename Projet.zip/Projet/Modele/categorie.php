<?php
require('../Modele/connect.php');
require('../Modele/affich3.php');

 ?>
